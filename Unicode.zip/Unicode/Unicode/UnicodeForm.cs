﻿/*
 * Created by: Zachary Kranabetter
 * Created on: March 28 2019
 * Created for: ICS3U Programming
 * Daily Assignment – Day #24 - Unicode
 * This program  takes the capital letters from A to Z along with the corresponding Unicode value and place each in a listbox
*/
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Unicode
{
    public partial class UnicodeForm : Form
    {
        public UnicodeForm()
        {
            InitializeComponent();
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            // declare my variables
            string letters;
            int counter = 1;
            const int MAX_VALUE = 26;

            // clear items in the listbox
            lstLetters.Items.Clear();

            for (counter = 1; counter < MAX_VALUE+1; counter++)
            {
                //Char.ConvertFromUtf32(counter);

                letters = Convert.ToString(counter);

                lstLetters.Items.Add(letters);            
            }
        }
    }
}
